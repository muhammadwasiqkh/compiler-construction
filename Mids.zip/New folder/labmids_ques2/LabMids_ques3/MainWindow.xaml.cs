﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LabMids_ques3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Compile_Click(object sender, RoutedEventArgs e)
        {
            // Define states:
            // S0: Initial state
            // S1: After 'start'
            // S2: After any valid action (accelerate, brake, right, left)
            // S3: After 'stop' (final state)
            // Se: Error state

            string Initial_State = "S0";
            string Final_State = "S3";

            var dict = new Dictionary<string, Dictionary<string, object>>();

            // Initial state - only accepts 'start'
            dict.Add("S0", new Dictionary<string, object>()
            {
                { "start", "S1" },
                { "stop", "Se" },
                { "accelerate", "Se" },
                { "brake", "Se" },
                { "right", "Se" },
                { "left", "Se" }
            });

            // After 'start' - can accept any action or 'stop'
            dict.Add("S1", new Dictionary<string, object>()
            {
                { "start", "Se" },
                { "stop", "S3" },
                { "accelerate", "S2" },
                { "brake", "S2" },
                { "right", "S2" },
                { "left", "S2" }
            });

            // After any action - can accept another action or 'stop'
            dict.Add("S2", new Dictionary<string, object>()
            {
                { "start", "Se" },
                { "stop", "S3" },
                { "accelerate", "S2" },
                { "brake", "S2" },
                { "right", "S2" },
                { "left", "S2" }
            });

            // Final state - only reached after 'stop'
            dict.Add("S3", new Dictionary<string, object>()
            {
                { "start", "Se" },
                { "stop", "Se" },
                { "accelerate", "Se" },
                { "brake", "Se" },
                { "right", "Se" },
                { "left", "Se" }
            });

            try
            {
                string state = Initial_State;
                string[] commands = Input.Text.ToLower().Split(' ');

                // Process each command
                foreach (string command in commands)
                {
                    // Validate command
                    if (!dict[state].ContainsKey(command))
                    {
                        Output.Text = "ERROR: Invalid command " + command;
                        return;
                    }

                    // Transition to next state
                    state = dict[state][command].ToString();

                    // Check for error state
                    if (state == "Se")
                    {
                        Output.Text = "ERROR: Invalid command sequence";
                        return;
                    }
                }

                // Check if we reached the final state
                if (state == Final_State)
                {
                    Output.Text = "RESULT OKAY";
                }
                else
                {
                    Output.Text = "ERROR: Incomplete command sequence";
                }
            }
            catch (Exception ex)
            {
                Output.Text = "ERROR: " + ex.Message;
            }
        }
    }
}