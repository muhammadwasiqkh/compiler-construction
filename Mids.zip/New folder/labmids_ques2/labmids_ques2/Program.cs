﻿using System;
using System.Collections.Generic;

class ToyCarStateMachine
{
    // Define states as an enumeration
    enum State
    {
        Idle,
        Started,
        Moving,
        TurningRight,
        Stopped
    }

    // Define valid commands as transitions
    static Dictionary<(State, string), State> transitions = new Dictionary<(State, string), State> {
        {(State.Idle, "Start"), State.Started},
        {(State.Started, "Accelerate"), State.Moving},
        {(State.Moving, "Right"), State.TurningRight},
        {(State.TurningRight, "Stop"), State.Stopped},
        {(State.Moving, "Stop"), State.Stopped},
        {(State.Started, "Stop"), State.Stopped}
    };

    static void Main()
    {
        Console.WriteLine("Enter the command sequence for the car (e.g., 'Start Accelerate Right Stop'):");
        string input = Console.ReadLine();
        string[] commands = input.Split(' ');

        State currentState = State.Idle;

        foreach (string command in commands)
        {
            if (transitions.ContainsKey((currentState, command)))
            {
                currentState = transitions[(currentState, command)];
                Console.WriteLine($"Executing '{command}', new state: {currentState}");
            }
            else
            {
                Console.WriteLine($"Invalid command '{command}' from state '{currentState}'. The car does not support this command.");
                return;
            }
        }

        Console.WriteLine($"Final state: {currentState}");
       
    }
}
